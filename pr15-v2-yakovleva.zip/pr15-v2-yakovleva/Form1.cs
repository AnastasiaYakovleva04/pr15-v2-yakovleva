﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr15_v2_yakovleva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        ComplexNumbers cn1 = new ComplexNumbers();
        ComplexNumbers cn2 = new ComplexNumbers();
        private void ready_Click(object sender, EventArgs e)
        {
            if (cNum1.Text == "" || cNum2.Text == "")
                MessageBox.Show("Все поля должны быть заполнены", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                cn1.Initialize(cNum1.Text);
                cn2.Initialize(cNum2.Text);
                if (cn1.Real == 0 && cn1.Imaginary == 0 || cn2.Real == 0 && cn2.Imaginary == 0)
                    MessageBox.Show("Возжможна ошибка в записи компексных чисел или введены нулевые значения", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    panel2.Visible = true;
                }
            }
        }
        private void sum_Click(object sender, EventArgs e)
        {
            string sum = cn1.Sum(cn1.Real, cn1.Imaginary, cn2.Real, cn2.Imaginary);
            MessageBox.Show(sum, "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void diff_Click(object sender, EventArgs e)
        {
            string diff = cn1.Diff(cn1.Real, cn1.Imaginary, cn2.Real, cn2.Imaginary);
            MessageBox.Show(diff, "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void multiply_Click(object sender, EventArgs e)
        {
            string mltpl = cn1.Multiply(cn1.Real, cn1.Imaginary, cn2.Real, cn2.Imaginary);
            MessageBox.Show(mltpl, "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void allAct_Click(object sender, EventArgs e)
        {
            string sum = cn1.Sum(cn1.Real, cn1.Imaginary, cn2.Real, cn2.Imaginary);
            string diff = cn1.Diff(cn1.Real, cn1.Imaginary, cn2.Real, cn2.Imaginary);
            string mltpl = cn1.Multiply(cn1.Real, cn1.Imaginary, cn2.Real, cn2.Imaginary);
            MessageBox.Show($"Сумма = {sum}\nРазность = {diff}\nПроизведение = {mltpl}", "Успешно", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
