﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr15_v2_yakovleva
{
    class ComplexNumbers
    {
        public double Real { get; set; } //действительная часть
        public double Imaginary { get; set; } //мнимая часть

        public ComplexNumbers() { }
        public void Initialize(string mathEx)
        {
            if (mathEx[mathEx.Length - 1] == 'i')
            {
                string[] parts = new string[2];
                mathEx = mathEx.Remove(mathEx.Length-1);
                if (mathEx.Contains('+'))
                    parts = mathEx.Split('+');
                else if (mathEx.Contains('-'))
                {
                    int minusCount = 0;
                    for (int i = 0; i<mathEx.Length; i++)
                    {
                        if (mathEx[i] == '-')
                            minusCount++;
                    }
                    if (minusCount == 1)
                        parts[0] = mathEx.Substring(0, mathEx.Length-mathEx.LastIndexOf('-')-1);
                    else
                        parts[0] = mathEx.Substring(0, mathEx.Length-mathEx.LastIndexOf('-'));
                    parts[1] = mathEx.Substring(mathEx.LastIndexOf('-'));
                }
                if (double.TryParse(parts[0], out double real) && double.TryParse(parts[1], out double imaginary))
                {
                    Real = real;
                    Imaginary = imaginary;
                }
            }
            else
            {
                Real = 0;
                Imaginary = 0;
            }
        }
        public string Sum(double a1, double b1, double a2, double b2)
        {
            string s;
            if (b1+b2 < 0)
                s = (a1 + a2).ToString() + (b1 + b2).ToString() + 'i';
            else
                s = (a1 + a2).ToString() + "+" + (b1 + b2).ToString() + 'i';
            return s;
        }
        public string Diff(double a1, double b1, double a2, double b2)
        {
            string s;
            if (b1 + b2 < 0)
                s = (a1 - a2).ToString() + (b1 - b2).ToString() + 'i';
            else
                s = (a1 - a2).ToString() + '+' + (b1 - b2).ToString() + 'i';
            return s;
        }
        public string Multiply(double a1, double b1, double a2, double b2)
        {
            string s;
            if (a1 * b2 + a2 * b1 < 0)
                s = (a1 * a2 - b1 * b2).ToString() + (a1 * b2 + a2 * b1).ToString() + 'i'; 
            else
                s = (a1 * a2 - b1 * b2).ToString() + '+' + (a1 * b2 + a2 * b1).ToString() + 'i'; 
            return s;
        }
    }
}
